import requests
import json
import sys
import time


def search_europe_pmc(query, max_results=4):
    """使用 Europe PMC 的免费 REST API，稳定性极高"""
    base_url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
    params = {
        "query": query,
        "format": "json",
        "pageSize": max_results,
        "resultType": "core"
    }
    try:
        response = requests.get(base_url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        results = []
        if "resultList" in data and "result" in data["resultList"]:
            for item in data["resultList"]["result"]:
                results.append({
                    "pmid": item.get("pmid", ""),
                    "title": item.get("title", ""),
                    "authors": item.get("authorString", ""),
                    "journal": item.get("journalTitle", ""),
                    "year": item.get("pubYear", ""),
                    "doi": item.get("doi", ""),
                    "abstract": item.get("abstractText", "Abstract not available.")
                })
        return results
    except Exception as e:
        print(f"API请求失败: {e}", file=sys.stderr)
        return []


def main():
    # 接收从 Prompt 传来的检索词
    query = sys.argv[1] if len(sys.argv) > 1 else "exam anxiety college students"

    # 启动计时器
    start_time = time.time()
    final_results = []

    # ================= 第 1 轮检索 =================
    print(f"开始第1轮检索，关键词: {query}", file=sys.stderr)
    round1_results = search_europe_pmc(query, max_results=4)
    final_results.extend(round1_results)

    elapsed_time = time.time() - start_time
    print(f"第1轮结束，耗时: {elapsed_time:.2f}秒，找到 {len(final_results)} 篇。", file=sys.stderr)

    # ================= 第 2 轮检索（时间与数量控制） =================
    # 规则：如果时间还没到1分钟，且结果不足4篇，进行第2轮补充检索
    if elapsed_time < 60 and len(final_results) < 4:
        print("时间未到1分钟且文献不足3篇，开启第2轮补充检索...", file=sys.stderr)
        # 稍微扩大检索范围（比如加入 college students 或 systematic review）
        round2_results = search_europe_pmc(f"{query} college students", max_results=4)

        # 去重合并
        existing_pmids = [r["pmid"] for r in final_results]
        for item in round2_results:
            if item["pmid"] not in existing_pmids:
                final_results.append(item)
            if len(final_results) >= 4:  # 凑齐4篇立刻停止
                break

    elapsed_time = time.time() - start_time
    print(f"正常检索结束，总耗时: {elapsed_time:.2f}秒，最终找到 {len(final_results)} 篇。", file=sys.stderr)

    # ================= 兜底逻辑：超时且零结果 =================
    # 规则：如果检索超过了1分钟（或者前面所有轮次结束），依然一篇都没找到，强行兜底找1篇
    if len(final_results) == 0:
        print("严重警告：一篇文献都没找到。执行强制兜底策略...", file=sys.stderr)
        # 换用极其宽泛、绝对能搜到的关键词，只求返回1篇
        fallback_results = search_europe_pmc("university students mental health", max_results=1)
        if fallback_results:
            final_results.extend(fallback_results)
            print("兜底策略成功，已强行获取1篇文献。", file=sys.stderr)

    # 最终检查：如果连兜底都失败了（比如彻底断网）
    if len(final_results) == 0:
        print("兜底策略依然失败，无网络返回。", file=sys.stderr)

    # ================= 输出给大模型 =================
    # 必须是纯 JSON 格式输出
    print(json.dumps(final_results, ensure_ascii=False))


if __name__ == "__main__":
    main()


---
name: verification-tools
description: "用于核验文献的真实性。通过传入 DOI 或 PMID，自动去 Crossref 数据库查询并返回真实的标题、作者和年份。"
---

# 执行说明
1. 提取待核验文献列表中**所有的 DOI**。
2. **将所有的 DOI 用英文逗号 `,` 拼接起来**，作为参数传入。
   *(例如：如果上游给了 S1 的 DOI 是 `10.1/a`，S2 是 `10.2/b`，请传入 `10.1/a,10.2/b`)*
3. 运行 `scripts/verify_metadata.py`，将拼接好的字符串作为参数传入。
4. 脚本会自动调用 Crossref API 并返回 JSON 格式的元数据。
5. 请根据返回结果中的 `status` 字段（`verified`、`not_found`、`error`）进行判断，然后更新 `metadata_status` 字段。
   - 如果 `status` 为 `verified`，核对标题是否一致。
   - 如果 `status` 为 `not_found`，标记为 `incorrect`。
   - 如果 `status` 为 `error`，标记为 `not_confirmed`。
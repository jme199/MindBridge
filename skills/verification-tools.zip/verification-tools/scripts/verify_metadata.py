import requests
import json
import sys


def verify_doi(doi):
    if not doi or not doi.strip():
        return {"doi": doi, "error": "Missing DOI"}

    doi = doi.strip()
    url = f"https://api.crossref.org/works/{doi}"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json().get("message", {})
            return {
                "doi": doi,
                "title": data.get("title", [""])[0] if data.get("title") else "",
                "authors": ", ".join([f"{a.get('given', '')} {a.get('family', '')}" for a in data.get("author", [])]),
                "year": data.get("published", {}).get("date-parts", [[None]])[0][0],
                "journal": data.get("container-title", [""])[0] if data.get("container-title") else "",
                "status": "verified"
            }
        else:
            return {"doi": doi, "status": "not_found", "error": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"doi": doi, "status": "error", "error": str(e)}


if __name__ == "__main__":
    # 支持接收一个逗号分隔的 DOI 字符串，例如: "10.1234/abc,10.5678/def"
    raw_input = sys.argv[1] if len(sys.argv) > 1 else ""
    dois = [d.strip() for d in raw_input.split(",") if d.strip()]

    if not dois:
        print(json.dumps([], ensure_ascii=False))
        sys.exit(0)

    results = []
    for doi in dois:
        results.append(verify_doi(doi))

    print(json.dumps(results, ensure_ascii=False))